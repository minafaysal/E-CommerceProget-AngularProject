import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.scss']
})
export class LogInComponent implements OnInit {

  constructor(private fb:FormBuilder) { }
  LoginForm:any;
  RegArray:any;




  ngOnInit(): void {
    this.LoginForm=new FormGroup({
      "email":new FormControl(null,[Validators.required,Validators.email]),
      "password":new FormControl(null,[ Validators.required]),


    },);
  }
  // submit button
  // submitData(){
  //   console.log(this.LoginForm.value);
  //   if(this.LoginForm.valid){
  //     alert(`Thank you ${this.LoginForm.value.fristname}`);
  //     this.LoginForm.reset();
  //   }
  // }

  get email(){
    return this.LoginForm.get('email');
  }
  get password() {
    return this.LoginForm.get('password');
  }


}
